<?php
session_start();
require 'config.php';

echo "<!DOCTYPE html>
<html>
<head>
    <title>Database Setup</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f0fdfd;
            padding: 20px;
            margin: 0;
        }
        .container {
            max-width: 700px;
            margin: 50px auto;
            background-color: white;
            padding: 30px;
            border-radius: 8px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
        }
        h1 {
            color: #0b7c88;
            text-align: center;
        }
        .result {
            padding: 15px;
            margin: 10px 0;
            border-radius: 5px;
            font-size: 16px;
        }
        .success {
            background-color: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
        }
        .error {
            background-color: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
        }
        .info {
            background-color: #d1ecf1;
            color: #0c5460;
            border: 1px solid #bee5eb;
        }
        code {
            background-color: #f4f4f4;
            padding: 2px 5px;
            border-radius: 3px;
        }
    </style>
</head>
<body>
    <div class='container'>
        <h1>🔧 Database Setup</h1>";

// Check connection
if ($conn->connect_error) {
    echo "<div class='result error'>❌ Connection Failed: " . $conn->connect_error . "</div>";
    exit();
}

echo "<div class='result success'>✅ Connected to database successfully</div>";

// Array of SQL statements
$tables = [
    "medicine" => "CREATE TABLE IF NOT EXISTS medicine (
        id INT PRIMARY KEY AUTO_INCREMENT,
        image VARCHAR(255),
        name VARCHAR(100) NOT NULL,
        price DECIMAL(10, 2),
        description TEXT
    )",
    
    "users" => "CREATE TABLE IF NOT EXISTS users (
        id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
        username VARCHAR(50) NOT NULL UNIQUE,
        password VARCHAR(255) NOT NULL
    )",
    
    "feedback" => "CREATE TABLE IF NOT EXISTS feedback (
        id INT AUTO_INCREMENT PRIMARY KEY,
        user_id INT,
        subject VARCHAR(255) NOT NULL,
        message TEXT NOT NULL,
        image_path VARCHAR(255),
        submitted_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        status VARCHAR(50) DEFAULT 'Pending',
        FOREIGN KEY (user_id) REFERENCES users(id)
    )",
    
    "orders" => "CREATE TABLE IF NOT EXISTS orders (
        id INT PRIMARY KEY AUTO_INCREMENT,
        user_id INT NOT NULL,
        name VARCHAR(255) NOT NULL,
        price DECIMAL(10, 2) NOT NULL,
        address TEXT NOT NULL,
        phone VARCHAR(20),
        pincode VARCHAR(20),
        order_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        user VARCHAR(255)
    )",
    
    "replay" => "CREATE TABLE IF NOT EXISTS replay (
        id INT AUTO_INCREMENT PRIMARY KEY,
        sender VARCHAR(255),
        receiver VARCHAR(255),
        message TEXT,
        sent_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )"
];

// Create tables
foreach ($tables as $table_name => $sql) {
    if ($conn->query($sql) === TRUE) {
        echo "<div class='result success'>✅ Table '<code>$table_name</code>' created/exists successfully</div>";
    } else {
        echo "<div class='result error'>❌ Error creating table '<code>$table_name</code>': " . $conn->error . "</div>";
    }
}

// Verify tables
echo "<hr><h2>Verifying Tables:</h2>";
$result = $conn->query("SHOW TABLES");
if ($result) {
    echo "<div class='result info'><strong>Tables in database:</strong><br>";
    $table_count = 0;
    while ($row = $result->fetch_row()) {
        echo "📋 " . htmlspecialchars($row[0]) . "<br>";
        $table_count++;
    }
    echo "<strong>Total: $table_count tables</strong></div>";
} else {
    echo "<div class='result error'>❌ Could not retrieve tables: " . $conn->error . "</div>";
}

echo "<hr>";
echo "<div class='result info' style='text-align: center;'>";
echo "<strong>Database setup complete!</strong><br>";
echo "You can now:<br>";
echo "1. Delete this setup file<br>";
echo "2. Try logging in/registering at <a href='index.php'>index.php</a><br>";
echo "3. Or test with <a href='test.php'>test.php</a>";
echo "</div>";

echo "    </div>
</body>
</html>";

$conn->close();
?>
