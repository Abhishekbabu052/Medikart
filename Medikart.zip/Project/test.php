<?php
session_start();
require 'config.php';

echo "<!DOCTYPE html>
<html>
<head>
    <title>Database Connection Test</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f0fdfd;
            padding: 20px;
            margin: 0;
        }
        .container {
            max-width: 600px;
            margin: 50px auto;
            background-color: white;
            padding: 30px;
            border-radius: 8px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
        }
        h1 {
            color: #0b7c88;
            text-align: center;
        }
        .test-result {
            padding: 15px;
            margin: 10px 0;
            border-radius: 5px;
            font-size: 16px;
        }
        .success {
            background-color: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
        }
        .error {
            background-color: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
        }
        .info {
            background-color: #d1ecf1;
            color: #0c5460;
            border: 1px solid #bee5eb;
        }
        code {
            background-color: #f4f4f4;
            padding: 2px 5px;
            border-radius: 3px;
        }
    </style>
</head>
<body>
    <div class='container'>
        <h1>🔧 Server Connection Test</h1>";

// Test 1: Check if config.php was loaded
echo "<div class='test-result success'>✅ <strong>Config.php loaded successfully</strong></div>";

// Test 2: Check database connection
if ($conn->connect_error) {
    echo "<div class='test-result error'>❌ <strong>Database Connection Failed:</strong> " . $conn->connect_error . "</div>";
} else {
    echo "<div class='test-result success'>✅ <strong>Database Connection Successful</strong></div>";
    
    // Test 3: Get database info
    echo "<div class='test-result info'>";
    echo "<strong>Server Info:</strong><br>";
    echo "Host: <code>" . $conn->server_info . "</code><br>";
    echo "Database: <code>" . (defined('DB_NAME') ? DB_NAME : 'Connected') . "</code><br>";
    echo "Charset: <code>" . $conn->get_charset()->charset . "</code>";
    echo "</div>";
    
    // Test 4: Check tables
    $tables_result = $conn->query("SHOW TABLES");
    if ($tables_result) {
        echo "<div class='test-result info'>";
        echo "<strong>Available Tables:</strong><br>";
        $table_count = 0;
        while ($table = $tables_result->fetch_array()) {
            echo "📋 " . htmlspecialchars($table[0]) . "<br>";
            $table_count++;
        }
        if ($table_count === 0) {
            echo "<em>No tables found</em>";
        } else {
            echo "<strong>Total: $table_count tables</strong>";
        }
        echo "</div>";
    }
    
    // Test 5: Test a sample query
    echo "<div class='test-result info'>";
    echo "<strong>Sample Query Test:</strong><br>";
    $test_query = $conn->query("SELECT COUNT(*) as user_count FROM users");
    if ($test_query) {
        $row = $test_query->fetch_assoc();
        echo "✅ Users table query successful<br>";
        echo "Total Users: <code>" . $row['user_count'] . "</code>";
    } else {
        echo "⚠️ Could not query users table: " . $conn->error;
    }
    echo "</div>";
}

echo "    </div>
</body>
</html>";

$conn->close();
?>